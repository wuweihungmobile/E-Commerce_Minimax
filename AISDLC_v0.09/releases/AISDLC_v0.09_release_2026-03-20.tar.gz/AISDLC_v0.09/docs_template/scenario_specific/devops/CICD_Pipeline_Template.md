# CI/CD Pipeline 配置範本
# CI/CD Pipeline Configuration Template

> **🎯 文檔目的**
>
> 本範本提供 **CI/CD Pipeline 的標準化配置指引**，涵蓋主流 CI/CD 平台與最佳實踐。
>
> - **適用階段**: Stage 8 - 開發準備階段
> - **適用平台**: GitHub Actions、GitLab CI、Jenkins、Azure DevOps
> - **執行角色**: DevOps Engineer、SD-Architect、Dev Lead
> - **目標**: 建立自動化、可靠、安全的持續整合與部署流程

---

**版本**: v1.0
**最後更新**: 2025-11-21
**文檔類型**: DevOps 配置範本 | CI/CD
**相關文檔**:
- [Code_Review_Guidelines.md](../../../guides/user/process/Code_Review_Guidelines.md) - Code Review 指南
- [Testing_Plan_Template.md](../testing/Testing_Plan_Template.md) - 測試計畫範本
- [Deployment_Checklist.md](./Deployment_Checklist.md) - 部署檢查清單

---

## 📋 目錄

1. [CI/CD Pipeline 概覽](#cicd-pipeline-概覽)
2. [GitHub Actions 配置](#github-actions-配置)
3. [GitLab CI 配置](#gitlab-ci-配置)
4. [Jenkins Pipeline 配置](#jenkins-pipeline-配置)
5. [Azure DevOps Pipeline 配置](#azure-devops-pipeline-配置)
6. [通用最佳實踐](#通用最佳實踐)
7. [環境變數管理](#環境變數管理)
8. [部署策略](#部署策略)
9. [監控與告警](#監控與告警)

---

## CI/CD Pipeline 概覽

### Pipeline 階段定義

**標準 CI/CD Pipeline 包含以下階段**:

```mermaid
graph LR
    A[Code Push] --> B[Build]
    B --> C[Test]
    C --> D[Security Scan]
    D --> E[Quality Gate]
    E --> F[Deploy to Dev]
    F --> G[Integration Test]
    G --> H{Manual Approval?}
    H -->|Yes| I[Deploy to Staging]
    H -->|No| I
    I --> J[E2E Test]
    J --> K{Manual Approval?}
    K -->|Yes| L[Deploy to Production]
    K -->|No| M[Skip]
    L --> N[Smoke Test]
    N --> O[Monitoring]

    style B fill:#87CEEB
    style C fill:#87CEEB
    style D fill:#FFD700
    style E fill:#FFD700
    style F fill:#90EE90
    style I fill:#90EE90
    style L fill:#FF6B6B
    style O fill:#D3D3D3
```

**各階段說明**:

| 階段 | 目的 | 執行時間 | 失敗處理 |
|------|------|---------|---------|
| **Build** | 編譯程式碼、安裝依賴、打包 | 2-5 分鐘 | 立即停止 Pipeline |
| **Test** | 單元測試、整合測試 | 5-10 分鐘 | 立即停止 Pipeline |
| **Security Scan** | 安全漏洞掃描、依賴檢查 | 2-3 分鐘 | 警告或停止（依嚴重度） |
| **Quality Gate** | 程式碼品質檢查（SonarQube） | 1-2 分鐘 | 警告或停止（依設定） |
| **Deploy to Dev** | 部署至開發環境 | 2-5 分鐘 | 回滾至前一版本 |
| **Integration Test** | 開發環境整合測試 | 3-5 分鐘 | 標記失敗，通知團隊 |
| **Deploy to Staging** | 部署至測試環境 | 3-5 分鐘 | 回滾至前一版本 |
| **E2E Test** | 端對端測試 | 10-15 分鐘 | 標記失敗，通知團隊 |
| **Deploy to Production** | 部署至正式環境 | 5-10 分鐘 | 立即回滾 |
| **Smoke Test** | 正式環境冒煙測試 | 2-3 分鐘 | 立即回滾 |
| **Monitoring** | 持續監控關鍵指標 | 持續 | 觸發告警 |

---

## GitHub Actions 配置

### 完整配置範例

**檔案位置**: `.github/workflows/ci-cd.yml`

```yaml
name: CI/CD Pipeline

on:
  push:
    branches:
      - main
      - develop
      - 'release/**'
  pull_request:
    branches:
      - main
      - develop
  workflow_dispatch:  # 允許手動觸發

env:
  NODE_VERSION: '18.x'
  REGISTRY: ghcr.io
  IMAGE_NAME: ${{ github.repository }}

jobs:
  # ==================== Build Stage ====================
  build:
    name: Build and Compile
    runs-on: ubuntu-latest
    outputs:
      version: ${{ steps.version.outputs.version }}

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4
        with:
          fetch-depth: 0  # 完整歷史記錄（用於版本標記）

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'

      - name: Install Dependencies
        run: npm ci

      - name: Build Application
        run: npm run build

      - name: Generate Version
        id: version
        run: |
          echo "version=$(date +'%Y%m%d')-$(git rev-parse --short HEAD)" >> $GITHUB_OUTPUT

      - name: Upload Build Artifacts
        uses: actions/upload-artifact@v4
        with:
          name: build-${{ steps.version.outputs.version }}
          path: dist/
          retention-days: 7

  # ==================== Test Stage ====================
  test:
    name: Run Tests
    runs-on: ubuntu-latest
    needs: build

    strategy:
      matrix:
        test-type: [unit, integration]

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'

      - name: Install Dependencies
        run: npm ci

      - name: Run ${{ matrix.test-type }} Tests
        run: npm run test:${{ matrix.test-type }}

      - name: Generate Coverage Report
        if: matrix.test-type == 'unit'
        run: npm run test:coverage

      - name: Upload Coverage to Codecov
        if: matrix.test-type == 'unit'
        uses: codecov/codecov-action@v4
        with:
          token: ${{ secrets.CODECOV_TOKEN }}
          files: ./coverage/lcov.info
          fail_ci_if_error: true

      - name: Check Coverage Threshold
        if: matrix.test-type == 'unit'
        run: |
          COVERAGE=$(cat coverage/coverage-summary.json | jq '.total.lines.pct')
          if (( $(echo "$COVERAGE < 80" | bc -l) )); then
            echo "❌ Coverage $COVERAGE% is below threshold 80%"
            exit 1
          fi
          echo "✅ Coverage $COVERAGE% meets threshold"

  # ==================== Security Scan Stage ====================
  security:
    name: Security Scanning
    runs-on: ubuntu-latest
    needs: build

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Run Dependency Security Scan (Snyk)
        uses: snyk/actions/node@master
        env:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
        with:
          args: --severity-threshold=high

      - name: Run SAST (Static Application Security Testing)
        uses: github/codeql-action/init@v3
        with:
          languages: javascript

      - name: Perform CodeQL Analysis
        uses: github/codeql-action/analyze@v3

      - name: Run Secret Scanning
        uses: trufflesecurity/trufflehog@main
        with:
          path: ./
          base: main
          head: HEAD

  # ==================== Code Quality Stage ====================
  quality:
    name: Code Quality Check
    runs-on: ubuntu-latest
    needs: build

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4
        with:
          fetch-depth: 0  # SonarQube 需要完整歷史

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: 'npm'

      - name: Install Dependencies
        run: npm ci

      - name: Run Linter
        run: npm run lint

      - name: Run SonarQube Scan
        uses: SonarSource/sonarcloud-github-action@master
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
          SONAR_TOKEN: ${{ secrets.SONAR_TOKEN }}

  # ==================== Build Docker Image ====================
  docker:
    name: Build and Push Docker Image
    runs-on: ubuntu-latest
    needs: [test, security, quality]
    if: github.event_name == 'push' && (github.ref == 'refs/heads/main' || github.ref == 'refs/heads/develop')

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: Log in to Container Registry
        uses: docker/login-action@v3
        with:
          registry: ${{ env.REGISTRY }}
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}

      - name: Extract metadata
        id: meta
        uses: docker/metadata-action@v5
        with:
          images: ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}
          tags: |
            type=ref,event=branch
            type=sha,prefix={{branch}}-
            type=raw,value=latest,enable={{is_default_branch}}

      - name: Build and Push Docker Image
        uses: docker/build-push-action@v5
        with:
          context: .
          push: true
          tags: ${{ steps.meta.outputs.tags }}
          labels: ${{ steps.meta.outputs.labels }}
          cache-from: type=registry,ref=${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:buildcache
          cache-to: type=registry,ref=${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:buildcache,mode=max

  # ==================== Deploy to Development ====================
  deploy-dev:
    name: Deploy to Development
    runs-on: ubuntu-latest
    needs: docker
    if: github.ref == 'refs/heads/develop'
    environment:
      name: development
      url: https://dev.example.com

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Deploy to Kubernetes (Dev)
        uses: azure/k8s-deploy@v4
        with:
          manifests: |
            k8s/deployment.yaml
            k8s/service.yaml
          images: |
            ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:develop
          namespace: development

      - name: Run Integration Tests
        run: |
          npm run test:integration:dev
        env:
          API_BASE_URL: https://api.dev.example.com

  # ==================== Deploy to Staging ====================
  deploy-staging:
    name: Deploy to Staging
    runs-on: ubuntu-latest
    needs: docker
    if: github.ref == 'refs/heads/main'
    environment:
      name: staging
      url: https://staging.example.com

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Deploy to Kubernetes (Staging)
        uses: azure/k8s-deploy@v4
        with:
          manifests: |
            k8s/deployment.yaml
            k8s/service.yaml
          images: |
            ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:main
          namespace: staging

      - name: Run E2E Tests
        run: |
          npm run test:e2e:staging
        env:
          API_BASE_URL: https://api.staging.example.com

      - name: Performance Test
        run: |
          npm run test:performance:staging

  # ==================== Deploy to Production ====================
  deploy-production:
    name: Deploy to Production
    runs-on: ubuntu-latest
    needs: [deploy-staging]
    if: github.ref == 'refs/heads/main'
    environment:
      name: production
      url: https://example.com

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Deploy to Kubernetes (Production) - Blue/Green
        uses: azure/k8s-deploy@v4
        with:
          manifests: |
            k8s/deployment.yaml
            k8s/service.yaml
          images: |
            ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:latest
          namespace: production
          strategy: blue-green

      - name: Run Smoke Tests
        run: |
          npm run test:smoke:production
        env:
          API_BASE_URL: https://api.example.com

      - name: Validate Deployment
        run: |
          # 檢查健康檢查端點
          RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" https://api.example.com/health)
          if [ $RESPONSE -ne 200 ]; then
            echo "❌ Health check failed: $RESPONSE"
            exit 1
          fi
          echo "✅ Health check passed"

      - name: Notify Deployment Success
        uses: 8398a7/action-slack@v3
        with:
          status: ${{ job.status }}
          text: '🚀 Production deployment successful!'
          webhook_url: ${{ secrets.SLACK_WEBHOOK }}
        if: success()

      - name: Rollback on Failure
        if: failure()
        run: |
          kubectl rollout undo deployment/app -n production
          echo "❌ Deployment failed. Rolled back to previous version."

  # ==================== Notification ====================
  notify:
    name: Send Notifications
    runs-on: ubuntu-latest
    needs: [deploy-production]
    if: always()

    steps:
      - name: Notify Slack
        uses: 8398a7/action-slack@v3
        with:
          status: ${{ job.status }}
          fields: repo,message,commit,author,action,eventName,ref,workflow
          webhook_url: ${{ secrets.SLACK_WEBHOOK }}

      - name: Create GitHub Release (on main)
        if: github.ref == 'refs/heads/main' && success()
        uses: actions/create-release@v1
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        with:
          tag_name: v${{ needs.build.outputs.version }}
          release_name: Release v${{ needs.build.outputs.version }}
          draft: false
          prerelease: false
```

### GitHub Actions 最佳實踐

| 最佳實踐 | 說明 | 範例 |
|---------|------|------|
| **使用 Matrix Strategy** | 並行執行多個測試 | `strategy.matrix.test-type: [unit, integration]` |
| **快取依賴** | 加速 Pipeline 執行 | `cache: 'npm'` |
| **Artifact 管理** | 儲存建置產物 | `actions/upload-artifact@v4` |
| **環境隔離** | 使用 Environment 管理部署 | `environment: production` |
| **Manual Approval** | 正式環境需人工批准 | `environment` + Branch Protection |
| **Secrets 管理** | 敏感資料使用 Secrets | `${{ secrets.CODECOV_TOKEN }}` |

---

## GitLab CI 配置

### 完整配置範例

**檔案位置**: `.gitlab-ci.yml`

```yaml
# GitLab CI/CD Pipeline Configuration

variables:
  NODE_VERSION: "18"
  DOCKER_DRIVER: overlay2
  DOCKER_TLS_CERTDIR: "/certs"
  REGISTRY: registry.gitlab.com
  IMAGE_NAME: $CI_REGISTRY_IMAGE

stages:
  - build
  - test
  - security
  - quality
  - package
  - deploy-dev
  - deploy-staging
  - deploy-production

# ==================== Build Stage ====================
build:
  stage: build
  image: node:${NODE_VERSION}
  cache:
    key: ${CI_COMMIT_REF_SLUG}
    paths:
      - node_modules/
      - .npm/
  script:
    - npm ci --cache .npm --prefer-offline
    - npm run build
  artifacts:
    paths:
      - dist/
    expire_in: 1 week
  only:
    - main
    - develop
    - merge_requests

# ==================== Unit Test ====================
test:unit:
  stage: test
  image: node:${NODE_VERSION}
  cache:
    key: ${CI_COMMIT_REF_SLUG}
    paths:
      - node_modules/
    policy: pull
  script:
    - npm run test:unit
    - npm run test:coverage
  coverage: '/Lines\s*:\s*(\d+\.\d+)%/'
  artifacts:
    reports:
      coverage_report:
        coverage_format: cobertura
        path: coverage/cobertura-coverage.xml
      junit: junit.xml
  only:
    - main
    - develop
    - merge_requests

# ==================== Integration Test ====================
test:integration:
  stage: test
  image: node:${NODE_VERSION}
  services:
    - postgres:14
    - redis:7
  variables:
    POSTGRES_DB: test_db
    POSTGRES_USER: test_user
    POSTGRES_PASSWORD: test_password
    DATABASE_URL: "postgresql://test_user:test_password@postgres:5432/test_db"
    REDIS_URL: "redis://redis:6379"
  cache:
    key: ${CI_COMMIT_REF_SLUG}
    paths:
      - node_modules/
    policy: pull
  script:
    - npm run test:integration
  only:
    - main
    - develop
    - merge_requests

# ==================== Security Scan ====================
security:dependencies:
  stage: security
  image: node:${NODE_VERSION}
  script:
    - npm audit --audit-level=moderate
  allow_failure: true
  only:
    - main
    - develop
    - merge_requests

security:sast:
  stage: security
  variables:
    SAST_EXCLUDED_PATHS: "spec, test, tests, tmp, node_modules"
  script:
    - echo "Running SAST..."
  artifacts:
    reports:
      sast: gl-sast-report.json
  only:
    - main
    - develop
    - merge_requests

# ==================== Code Quality ====================
code_quality:
  stage: quality
  image: sonarsource/sonar-scanner-cli:latest
  variables:
    SONAR_USER_HOME: "${CI_PROJECT_DIR}/.sonar"
    GIT_DEPTH: "0"
  cache:
    key: "${CI_JOB_NAME}"
    paths:
      - .sonar/cache
  script:
    - sonar-scanner
  allow_failure: true
  only:
    - main
    - develop
    - merge_requests

lint:
  stage: quality
  image: node:${NODE_VERSION}
  cache:
    key: ${CI_COMMIT_REF_SLUG}
    paths:
      - node_modules/
    policy: pull
  script:
    - npm run lint
  only:
    - main
    - develop
    - merge_requests

# ==================== Build Docker Image ====================
docker:build:
  stage: package
  image: docker:24
  services:
    - docker:24-dind
  before_script:
    - docker login -u $CI_REGISTRY_USER -p $CI_REGISTRY_PASSWORD $CI_REGISTRY
  script:
    - docker build -t $IMAGE_NAME:$CI_COMMIT_SHORT_SHA .
    - docker tag $IMAGE_NAME:$CI_COMMIT_SHORT_SHA $IMAGE_NAME:$CI_COMMIT_REF_SLUG
    - docker push $IMAGE_NAME:$CI_COMMIT_SHORT_SHA
    - docker push $IMAGE_NAME:$CI_COMMIT_REF_SLUG
    - |
      if [ "$CI_COMMIT_BRANCH" == "main" ]; then
        docker tag $IMAGE_NAME:$CI_COMMIT_SHORT_SHA $IMAGE_NAME:latest
        docker push $IMAGE_NAME:latest
      fi
  only:
    - main
    - develop

# ==================== Deploy to Development ====================
deploy:dev:
  stage: deploy-dev
  image: alpine/kubectl:latest
  environment:
    name: development
    url: https://dev.example.com
    on_stop: stop:dev
  script:
    - kubectl config use-context development
    - kubectl set image deployment/app app=$IMAGE_NAME:$CI_COMMIT_SHORT_SHA -n development
    - kubectl rollout status deployment/app -n development
  only:
    - develop

stop:dev:
  stage: deploy-dev
  image: alpine/kubectl:latest
  environment:
    name: development
    action: stop
  script:
    - kubectl delete deployment app -n development
  when: manual
  only:
    - develop

# ==================== Deploy to Staging ====================
deploy:staging:
  stage: deploy-staging
  image: alpine/kubectl:latest
  environment:
    name: staging
    url: https://staging.example.com
  script:
    - kubectl config use-context staging
    - kubectl set image deployment/app app=$IMAGE_NAME:$CI_COMMIT_SHORT_SHA -n staging
    - kubectl rollout status deployment/app -n staging
  only:
    - main

test:e2e:staging:
  stage: deploy-staging
  image: mcr.microsoft.com/playwright:latest
  needs: ["deploy:staging"]
  script:
    - npm run test:e2e:staging
  artifacts:
    when: always
    paths:
      - playwright-report/
    expire_in: 30 days
  only:
    - main

# ==================== Deploy to Production ====================
deploy:production:
  stage: deploy-production
  image: alpine/kubectl:latest
  environment:
    name: production
    url: https://example.com
  script:
    - kubectl config use-context production
    - kubectl set image deployment/app app=$IMAGE_NAME:latest -n production
    - kubectl rollout status deployment/app -n production
    - |
      # Smoke Test
      RESPONSE=$(wget --spider -S "https://api.example.com/health" 2>&1 | grep "HTTP/" | awk '{print $2}')
      if [ "$RESPONSE" != "200" ]; then
        echo "❌ Health check failed"
        kubectl rollout undo deployment/app -n production
        exit 1
      fi
      echo "✅ Deployment successful"
  when: manual
  only:
    - main
```

### GitLab CI 特色功能

| 功能 | 說明 | 優勢 |
|------|------|------|
| **內建 Container Registry** | 不需額外設定 Docker Registry | 簡化配置 |
| **環境管理** | 內建環境追蹤與部署歷史 | 視覺化部署狀態 |
| **Auto DevOps** | 自動產生 Pipeline | 快速啟動 |
| **Services** | 測試時啟動依賴服務（DB, Redis） | 整合測試更容易 |

---

## Jenkins Pipeline 配置

### Jenkinsfile (Declarative Pipeline)

**檔案位置**: `Jenkinsfile`

```groovy
pipeline {
    agent any

    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
        timestamps()
        timeout(time: 1, unit: 'HOURS')
    }

    environment {
        NODE_VERSION = '18'
        DOCKER_REGISTRY = 'registry.example.com'
        IMAGE_NAME = 'myapp'
        SLACK_CHANNEL = '#deployments'
    }

    stages {
        stage('Checkout') {
            steps {
                checkout scm
                script {
                    env.GIT_COMMIT_SHORT = sh(returnStdout: true, script: 'git rev-parse --short HEAD').trim()
                    env.VERSION = "${env.BUILD_NUMBER}-${env.GIT_COMMIT_SHORT}"
                }
            }
        }

        stage('Build') {
            agent {
                docker {
                    image "node:${NODE_VERSION}"
                    args '-v $HOME/.npm:/.npm'
                }
            }
            steps {
                sh 'npm ci'
                sh 'npm run build'
                stash includes: 'dist/**', name: 'build-artifacts'
            }
        }

        stage('Test') {
            parallel {
                stage('Unit Tests') {
                    agent {
                        docker {
                            image "node:${NODE_VERSION}"
                        }
                    }
                    steps {
                        sh 'npm ci'
                        sh 'npm run test:unit'
                        sh 'npm run test:coverage'
                    }
                    post {
                        always {
                            junit 'junit.xml'
                            publishHTML([
                                reportDir: 'coverage',
                                reportFiles: 'index.html',
                                reportName: 'Coverage Report'
                            ])
                        }
                    }
                }

                stage('Integration Tests') {
                    agent {
                        docker {
                            image "node:${NODE_VERSION}"
                        }
                    }
                    steps {
                        sh 'npm ci'
                        sh 'npm run test:integration'
                    }
                }
            }
        }

        stage('Security Scan') {
            parallel {
                stage('Dependency Check') {
                    steps {
                        sh 'npm audit --audit-level=moderate'
                    }
                }

                stage('SAST') {
                    steps {
                        sh 'sonar-scanner'
                    }
                }
            }
        }

        stage('Build Docker Image') {
            when {
                anyOf {
                    branch 'main'
                    branch 'develop'
                }
            }
            steps {
                script {
                    docker.withRegistry("https://${DOCKER_REGISTRY}", 'docker-credentials') {
                        def app = docker.build("${IMAGE_NAME}:${VERSION}")
                        app.push()
                        if (env.BRANCH_NAME == 'main') {
                            app.push('latest')
                        }
                    }
                }
            }
        }

        stage('Deploy to Development') {
            when {
                branch 'develop'
            }
            steps {
                sh "kubectl set image deployment/app app=${DOCKER_REGISTRY}/${IMAGE_NAME}:${VERSION} -n development"
                sh "kubectl rollout status deployment/app -n development"
            }
        }

        stage('Deploy to Staging') {
            when {
                branch 'main'
            }
            steps {
                sh "kubectl set image deployment/app app=${DOCKER_REGISTRY}/${IMAGE_NAME}:${VERSION} -n staging"
                sh "kubectl rollout status deployment/app -n staging"
            }
        }

        stage('E2E Tests (Staging)') {
            when {
                branch 'main'
            }
            steps {
                sh 'npm run test:e2e:staging'
            }
        }

        stage('Deploy to Production') {
            when {
                branch 'main'
            }
            steps {
                input message: 'Deploy to Production?', ok: 'Deploy'
                sh "kubectl set image deployment/app app=${DOCKER_REGISTRY}/${IMAGE_NAME}:latest -n production"
                sh "kubectl rollout status deployment/app -n production"
            }
        }

        stage('Smoke Test') {
            when {
                branch 'main'
            }
            steps {
                script {
                    def response = sh(returnStdout: true, script: 'curl -s -o /dev/null -w "%{http_code}" https://api.example.com/health')
                    if (response != '200') {
                        error("Health check failed: ${response}")
                    }
                }
            }
        }
    }

    post {
        success {
            slackSend(
                channel: env.SLACK_CHANNEL,
                color: 'good',
                message: "✅ Pipeline Success: ${env.JOB_NAME} #${env.BUILD_NUMBER}"
            )
        }
        failure {
            slackSend(
                channel: env.SLACK_CHANNEL,
                color: 'danger',
                message: "❌ Pipeline Failed: ${env.JOB_NAME} #${env.BUILD_NUMBER}"
            )
        }
        always {
            cleanWs()
        }
    }
}
```

---

## Azure DevOps Pipeline 配置

### 完整配置範例

**檔案位置**: `azure-pipelines.yml`

```yaml
trigger:
  branches:
    include:
      - main
      - develop

pr:
  branches:
    include:
      - main
      - develop

variables:
  nodeVersion: '18.x'
  dockerRegistry: 'myregistry.azurecr.io'
  imageName: 'myapp'

stages:
  # ==================== Build Stage ====================
  - stage: Build
    displayName: 'Build Application'
    jobs:
      - job: BuildJob
        displayName: 'Build and Test'
        pool:
          vmImage: 'ubuntu-latest'
        steps:
          - task: NodeTool@0
            inputs:
              versionSpec: $(nodeVersion)
            displayName: 'Install Node.js'

          - script: |
              npm ci
              npm run build
            displayName: 'Install and Build'

          - task: PublishBuildArtifacts@1
            inputs:
              PathtoPublish: 'dist'
              ArtifactName: 'drop'
            displayName: 'Publish Artifacts'

  # ==================== Test Stage ====================
  - stage: Test
    displayName: 'Run Tests'
    dependsOn: Build
    jobs:
      - job: UnitTests
        displayName: 'Unit Tests'
        pool:
          vmImage: 'ubuntu-latest'
        steps:
          - task: NodeTool@0
            inputs:
              versionSpec: $(nodeVersion)

          - script: |
              npm ci
              npm run test:unit
              npm run test:coverage
            displayName: 'Run Unit Tests'

          - task: PublishTestResults@2
            inputs:
              testResultsFormat: 'JUnit'
              testResultsFiles: '**/junit.xml'

          - task: PublishCodeCoverageResults@1
            inputs:
              codeCoverageTool: 'Cobertura'
              summaryFileLocation: '$(System.DefaultWorkingDirectory)/coverage/cobertura-coverage.xml'

  # ==================== Deploy to Dev ====================
  - stage: DeployDev
    displayName: 'Deploy to Development'
    dependsOn: Test
    condition: and(succeeded(), eq(variables['Build.SourceBranch'], 'refs/heads/develop'))
    jobs:
      - deployment: DeployDevJob
        displayName: 'Deploy to Dev'
        environment: 'development'
        pool:
          vmImage: 'ubuntu-latest'
        strategy:
          runOnce:
            deploy:
              steps:
                - task: Kubernetes@1
                  inputs:
                    connectionType: 'Kubernetes Service Connection'
                    namespace: 'development'
                    command: 'apply'
                    useConfigurationFile: true
                    configurationType: 'inline'
                    inline: |
                      apiVersion: apps/v1
                      kind: Deployment
                      metadata:
                        name: myapp
                      spec:
                        replicas: 2
                        template:
                          spec:
                            containers:
                            - name: myapp
                              image: $(dockerRegistry)/$(imageName):$(Build.BuildId)

  # ==================== Deploy to Production ====================
  - stage: DeployProd
    displayName: 'Deploy to Production'
    dependsOn: DeployDev
    condition: and(succeeded(), eq(variables['Build.SourceBranch'], 'refs/heads/main'))
    jobs:
      - deployment: DeployProdJob
        displayName: 'Deploy to Production'
        environment: 'production'
        pool:
          vmImage: 'ubuntu-latest'
        strategy:
          runOnce:
            deploy:
              steps:
                - task: Kubernetes@1
                  inputs:
                    connectionType: 'Kubernetes Service Connection'
                    namespace: 'production'
                    command: 'apply'
                    useConfigurationFile: true
                    configurationType: 'inline'
                    inline: |
                      apiVersion: apps/v1
                      kind: Deployment
                      metadata:
                        name: myapp
                      spec:
                        replicas: 3
                        template:
                          spec:
                            containers:
                            - name: myapp
                              image: $(dockerRegistry)/$(imageName):latest
```

---

## 通用最佳實踐

### 1. Pipeline 效能優化

| 優化策略 | 說明 | 預期改善 |
|---------|------|---------|
| **並行執行** | 使用 Matrix/Parallel 策略 | 減少 30-50% 執行時間 |
| **快取依賴** | 快取 node_modules, Docker layers | 減少 40-60% 安裝時間 |
| **增量建置** | 僅建置變更的部分 | 減少 50-70% 建置時間 |
| **Docker Layer 優化** | 善用 Docker Cache | 減少 60-80% 映像建置時間 |

### 2. 安全性最佳實踐

| 安全措施 | 實作方式 | 重要性 |
|---------|---------|--------|
| **Secrets 管理** | 使用 CI/CD 平台的 Secrets 功能 | 🔴 必須 |
| **依賴掃描** | Snyk, npm audit | 🔴 必須 |
| **SAST 掃描** | SonarQube, CodeQL | 🟡 建議 |
| **Container 掃描** | Trivy, Clair | 🟡 建議 |
| **Least Privilege** | 最小權限原則 | 🔴 必須 |

### 3. 測試覆蓋率要求

參考 [SOP.md Stage 8 - Testing Standards](../../../scenarios/greenfield/SOP.md):

- ✅ 單元測試覆蓋率 ≥ 80%
- ✅ 整合測試覆蓋率 ≥ 60%
- ✅ E2E 測試覆蓋率 ≥ 40%

---

## 環境變數管理

### 環境變數分類

| 類型 | 範例 | 儲存方式 | 存取方式 |
|------|------|---------|---------|
| **公開變數** | `NODE_ENV`, `API_VERSION` | Pipeline YAML | 直接引用 |
| **敏感變數** | `DATABASE_URL`, `API_KEY` | Secrets Manager | `${{ secrets.XXX }}` |
| **環境特定** | `API_BASE_URL` (Dev/Staging/Prod) | Environment Variables | 依環境載入 |

### Secrets 管理範例

**GitHub Actions**:
```yaml
env:
  DATABASE_URL: ${{ secrets.DATABASE_URL }}
  JWT_SECRET: ${{ secrets.JWT_SECRET }}
  STRIPE_API_KEY: ${{ secrets.STRIPE_API_KEY }}
```

**GitLab CI**:
```yaml
variables:
  DATABASE_URL: $DATABASE_URL  # 在 GitLab Settings → CI/CD → Variables 設定
```

---

## 部署策略

### 1. Blue/Green Deployment（藍綠部署）

**適用情境**: 需要零停機時間、快速回滾

```yaml
# GitHub Actions 範例
- name: Blue/Green Deployment
  run: |
    # 部署 Green 環境
    kubectl apply -f k8s/deployment-green.yaml
    kubectl wait --for=condition=available deployment/app-green

    # 切換流量至 Green
    kubectl patch service app -p '{"spec":{"selector":{"version":"green"}}}'

    # 驗證 Green 環境
    npm run test:smoke

    # 成功後刪除 Blue 環境
    kubectl delete deployment app-blue
```

### 2. Canary Deployment（金絲雀部署）

**適用情境**: 漸進式部署、風險降低

```yaml
# 階段 1: 部署 10% 流量至新版本
- name: Canary 10%
  run: |
    kubectl apply -f k8s/deployment-canary.yaml
    kubectl scale deployment app-canary --replicas=1
    kubectl scale deployment app-stable --replicas=9

# 階段 2: 監控 15 分鐘
- name: Monitor Canary
  run: |
    sleep 900
    ERROR_RATE=$(curl -s https://api.example.com/metrics | jq '.error_rate')
    if (( $(echo "$ERROR_RATE > 0.01" | bc -l) )); then
      echo "❌ Canary failed, rolling back"
      kubectl delete deployment app-canary
      exit 1
    fi

# 階段 3: 逐步增加至 100%
- name: Promote Canary
  run: |
    kubectl scale deployment app-canary --replicas=10
    kubectl scale deployment app-stable --replicas=0
    kubectl delete deployment app-stable
```

### 3. Rolling Update（滾動更新）

**適用情境**: 標準部署、Kubernetes 預設策略

```yaml
apiVersion: apps/v1
kind: Deployment
spec:
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
```

---

## 監控與告警

### 部署監控指標

| 指標 | 說明 | 告警閾值 |
|------|------|---------|
| **部署成功率** | 成功部署次數 / 總部署次數 | < 95% |
| **部署時間** | 從開始到完成的時間 | > 30 分鐘 |
| **回滾次數** | 需要回滾的部署次數 | > 5% |
| **Pipeline 失敗率** | 失敗的 Pipeline 次數 | > 10% |

### Slack 通知範例

```yaml
- name: Notify Slack
  uses: 8398a7/action-slack@v3
  with:
    status: ${{ job.status }}
    text: |
      🚀 Deployment Status: ${{ job.status }}
      📦 Version: ${{ github.sha }}
      🌿 Branch: ${{ github.ref }}
      👤 Author: ${{ github.actor }}
    webhook_url: ${{ secrets.SLACK_WEBHOOK }}
  if: always()
```

---

## 變更歷史

| 版本 | 日期 | 變更內容 | 作者 |
|------|------|---------|------|
| v1.0 | 2025-11-21 | 初版建立：GitHub Actions、GitLab CI、Jenkins、Azure DevOps 完整配置範例、部署策略、監控告警 | AISDLC Team |

---

## 授權與使用

本文檔為 **AISDLC Framework v0.09** 的一部分，遵循專案整體授權條款。

**使用建議**:
- ✅ 可自由複製、修改此範本，以符合專案需求
- ✅ 可整合至團隊的 CI/CD 平台
- ✅ 建議根據專案規模調整 Pipeline 階段
- ✅ 建議定期檢視與優化 Pipeline 效能

---

**🔗 相關文檔**:
- [Code_Review_Guidelines.md](../../../guides/user/process/Code_Review_Guidelines.md) - Code Review 指南
- [SOP.md - Stage 8](../../../scenarios/greenfield/SOP.md#階段-8開發準備) - Testing Standards
- [Security_Design_Checklist.md](../../../guides/system/quality/Security_Design_Checklist.md) - 安全性設計檢查清單
