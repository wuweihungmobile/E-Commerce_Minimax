# Migration 技術棧遷移 SOP

**版本**: v0.09 | **最後更新**: 2026-02-12
> 📝 **關於範例連結說明**:
> 本 SOP 中部分連結為示例性質，實際使用時請根據您的專案結構調整路徑。

## 🎯 情境概述

**適用場景**：全技術棧遷移（前端/後端/DB 框架替換）、資料庫平台遷移、系統現代化（含新平台擴展）

**與 Refactoring 的區別**：
| 維度 | Refactoring | Migration |
|------|------------|-----------|
| **代碼變更** | 改善既有代碼結構 | 用新技術棧重寫 |
| **行為** | 功能不變 (Preserve Behavior) | 功能對等 + 可新增功能 |
| **技術棧** | 不變 | 全面替換 |
| **資料庫** | 通常不變 | 可能遷移 |
| **平台** | 不變 | 可能擴展新平台 |

**預計時間**:
- 📋 **AISDLC 規劃階段**: 4-8 小時
- 🔨 **實際執行階段**:
  - 小規模遷移（單層遷移，如僅 DB）: 2-4 週
  - 中規模遷移（雙層遷移，如前端+後端）: 4-8 週
  - 大規模遷移（全棧+新平台）: 8-20 週

**涉及角色**：SD, SA, Code-Analyzer, Dev-Senior, QA, Dev, BA, PM/PO, DevOps

**最終產出**：遷移映射報告 + 資料庫遷移計畫 + 遷移實作指引 + 驗證測試計畫 + 並行運行方案 + 前後對比報告

---

## 🤝 協作模式 (Phase 2: v0.03)

### 主要協作模式

#### 1. Lead-Support (主導-支援)
- **主導 Agent**: SD-Architect (遷移架構設計)
- **支援 Agents**: SA (需求重新分析), Code-Analyzer (影響評估), Dev-Senior (技術決策)
- **使用階段**: 遷移策略設計、架構映射、技術選型
- **模式說明**: SD 主導遷移架構，SA 確保業務邏輯完整，Code-Analyzer 評估遷移影響

#### 2. Sequential-Handoff (順序交接)
- **流程**: SA 需求分析 → SD 架構設計 → Dev 實作 → QA 驗證
- **使用階段**: 完整遷移生命週期
- **模式說明**: 嚴格順序交接確保每層遷移的品質

#### 3. Parallel-Execution (平行執行)
- **流程**: 前端遷移 ∥ 後端遷移 ∥ DB 遷移（在架構確認後可平行）
- **使用階段**: 多層同步遷移
- **模式說明**: 各層有獨立的介面契約，可平行開發

### 次要協作模式

#### 4. Peer-Review (同儕審查)
- **使用階段**: Code-Analyzer ↔ Dev-Senior 遷移方案審查
- **模式說明**: 確保遷移方案的技術可行性和風險可控

---

## 📋 前置準備檢查清單

### 必要材料
- [ ] 舊系統完整代碼庫存取權限
- [ ] 舊系統技術棧清單（框架/版本/依賴）
- [ ] 新技術棧選型確認
- [ ] 現有資料庫 Schema（DDL 匯出）
- [ ] API 文檔或端點清單
- [ ] 業務邏輯文檔（如有）
- [ ] 遷移時間預算與團隊資源

### 選擇性材料
- [ ] 代碼品質報告
- [ ] 效能基準數據
- [ ] 測試覆蓋率報告
- [ ] 架構圖
- [ ] 第三方服務清單（API Key/帳號）

---

## 🎯 Claude Code Skills 整合指引

| 階段 | 建議 Skill | 觸發時機 |
|------|-----------|---------|
| 階段 1 現況分析 | `/brownfield-analysis` | 舊系統分析 |
| 階段 1 現況分析 | `/sa-analyst` | 需求重新分析 |
| 階段 2 遷移設計 | `/sd-architect` | 新架構設計 |
| 階段 3 DB 遷移 | `/database-migration` | 資料庫遷移規劃 |
| 階段 3 DB 遷移 | `/integration-database` | DB 整合方案 |
| 階段 4 API 設計 | `/integration-api-client` | API 契約設計 |
| 階段 5 前端遷移 | `/dev-review` | 代碼審查 |
| 階段 6 行動端 | `/mobile-development` | 行動端開發 |
| 階段 7 測試 | `/qa-testing` | 測試策略 |
| 階段 7 測試 | `/testing-strategy` | 跨系統對比測試 |
| 階段 8 部署 | `/devops-github-actions` | CI/CD 建立 |
| 階段 8 部署 | `/release-management` | 發布管理 |
| 全程 | `/security-audit` | 安全審計 |
| 全程 | `/performance-optimization` | 效能基準對比 |

---

## 🔄 開發-編譯-測試循環 (AISDLC 強制規則)

> **🔴 CRITICAL**：遷移實作階段必須嚴格遵守。

```
遷移 1 個模組/功能
    ↓
立即編譯 → 編譯失敗？ → 🔴 停止修復
    ↓
執行單元測試 → 失敗？ → 🔴 停止修復
    ↓
執行新舊系統對比測試 → 結果不一致？ → 🔴 停止修復
    ↓
全部通過 ✅ → Commit → 繼續下一個
```

---

## 🚀 完整執行流程

> **📋 Workflow 對應**：本 SOP 對應 [migration-planning-flow](../../workflow/scenario-specific/migration-planning-flow.md)，
> 載入 AISDLC_INIT.md 後會自動啟動該 Workflow，引導以下 9 個階段。

### 階段 1：現況分析與需求提取 (1-2 小時)

**載入 Agents**: SA (Primary), Code-Analyzer (Primary), SD (Primary)

#### 步驟 1.1：載入 AISDLC 框架
```
「請載入 AISDLC_INIT.md (v0.09)，我要進行技術棧遷移」
```

#### 步驟 1.2：情境識別問答

系統詢問：
- 遷移範圍（僅前端/僅後端/僅 DB/全棧/全棧+新平台）
- 舊技術棧（前端框架/後端框架/DB/語言）
- 新技術棧（前端框架/後端框架/DB/語言）
- 是否為生產系統？（影響並行運行策略）
- 是否涉及資料庫遷移？
- 是否需要新平台？（Android/iOS/macOS/Desktop）
- 業務持續性要求（可停機/不可停機/可降級服務）
- 遷移時間預算

#### 步驟 1.3：舊系統全面掃描 (Code-Analyzer + SA)

**前端分析**：
- [ ] 頁面/元件清單與數量統計
- [ ] 路由結構映射
- [ ] 狀態管理結構（Store/State）
- [ ] 第三方 UI 元件庫清單

**後端分析**：
- [ ] API 端點清單與參數定義
- [ ] Service 層業務邏輯清單
- [ ] 中介層/Middleware 清單
- [ ] 排程任務清單

**資料庫分析**：
- [ ] Schema 完整匯出（表/欄位/型別/約束/索引）
- [ ] Stored Procedure / Function / Trigger 清單
- [ ] View / Materialized View 清單
- [ ] 資料量統計（各表行數/總大小）
- [ ] 平台特有功能使用清單

**業務邏輯提取**：
- [ ] 逐模組列出所有計算邏輯
- [ ] 逐模組列出所有驗證規則
- [ ] 逐模組列出所有狀態流轉

> 🔴 **人機協作點：現況分析確認**
> - ✅ 分析結果是否完整準確
> - ✅ 業務邏輯提取是否有遺漏
> - ✅ 補充 AI 無法識別的隱含邏輯

---

### 階段 2：遷移架構設計 (1-1.5 小時)

**載入 Agents**: SD (Lead), Dev-Senior, PM/PO (ROI 決策)

#### 步驟 2.1：技術棧映射表

| 維度 | 舊技術 | 新技術 | 映射策略 |
|------|--------|--------|---------|
| 前端框架 | [舊] | [新] | 元件逐一對應 |
| 狀態管理 | [舊] | [新] | Store 結構映射 |
| 路由 | [舊] | [新] | 路由表映射 |
| UI 元件庫 | [舊] | [新] | 替代方案表 |
| 後端框架 | [舊] | [新] | API 對應 |
| ORM | [舊] | [新] | Model 映射 |
| 認證 | [舊] | [新] | Auth 方案 |
| DB | [舊] | [新] | Schema 轉換 |

#### 步驟 2.2：遷移策略選擇

**推薦策略：分層漸進遷移 (Layered Progressive Migration)**

```
Phase 1: DB 層遷移 → Schema + 資料 + SP 轉換
    ↓
Phase 2: 後端層遷移 → API 重新實作 + 對比驗證
    ↓
Phase 3: 前端層遷移 → 逐模組重寫 + 功能對等測試
    ↓
Phase 4: 新平台開發 → API 穩定後啟動行動端
    ↓
Phase 5: 並行運行 → 雙系統驗證 + 漸進切換
    ↓
Phase 6: 舊系統退役
```

#### 步驟 2.3：並行運行設計

```
                    ┌─ 新前端 (React/Next.js)
用戶 → Load Balancer ┤
                    └─ 舊前端 (Vue 3)
                            │
                    ┌─ 新後端 (Spring Boot)
        API Gateway ┤
                    └─ 舊後端 (Python)
                            │
                    ┌─ 新 DB (PostgreSQL) ←── CDC 同步
                    └─ 舊 DB (Oracle)
```

> 🔴 **人機協作點：遷移架構確認**
> - ✅ 技術棧映射是否準確
> - ✅ 遷移策略是否合適
> - ✅ 並行運行方案是否可行
> - ✅ 預估時程是否合理

---

### 階段 3：資料庫遷移 (0.5-1 小時規劃 / 2-4 週執行)

**載入 Agents**: SD (Lead), Dev-Senior

#### 步驟 3.1：Schema 轉換

**資料型別映射表**（以 Oracle→PostgreSQL 為例）：

| Oracle | PostgreSQL | 注意事項 |
|--------|-----------|---------|
| NUMBER(p,s) | NUMERIC(p,s) | 精度一致 |
| VARCHAR2(n) | VARCHAR(n) | 語義相同 |
| CLOB | TEXT | 無長度限制 |
| BLOB | BYTEA | 二進位存儲 |
| DATE | TIMESTAMP | Oracle DATE 含時間 |
| SYSDATE | NOW() | 函式替換 |
| SEQUENCE | SERIAL / SEQUENCE | 兩種方式 |

#### 步驟 3.2：SQL 語法轉換

| Oracle 語法 | PostgreSQL 等價 |
|------------|----------------|
| NVL(a, b) | COALESCE(a, b) |
| DECODE(a,b,c,d) | CASE WHEN a=b THEN c ELSE d END |
| ROWNUM | LIMIT / ROW_NUMBER() |
| CONNECT BY | WITH RECURSIVE |
| (+) outer join | LEFT/RIGHT JOIN |
| DUAL | 直接 SELECT |
| DBMS_OUTPUT | RAISE NOTICE |

#### 步驟 3.3：Stored Procedure 遷移策略

| 策略 | 適用情境 | 優缺點 |
|------|---------|--------|
| **轉為應用層** | 業務邏輯 SP | ✅ 可測試、可維護 / ❌ 需重寫 |
| **轉為 PL/pgSQL** | 資料處理 SP | ✅ 改動小 / ❌ 仍耦合 DB |
| **移除** | 不再需要的 SP | ✅ 減少複雜度 |

#### 步驟 3.4：資料遷移計畫

```
1. Schema 建立（DDL 轉換）
2. 靜態資料遷移（主檔/參數檔）
3. 動態資料遷移（交易資料）
4. 資料驗證（行數/加總/抽樣比對）
5. 增量同步方案（CDC / 雙寫）
6. 切換演練
```

**推薦工具**：ora2pg, pgloader, AWS DMS, Flyway (Schema Versioning)

> 🔴 **人機協作點：DB 遷移計畫確認**

---

### 階段 4：後端遷移設計 (30-40 分鐘規劃)

**載入 Agents**: SD + Dev-Senior + QA

#### 步驟 4.1：API 契約定義

- [ ] RESTful API 端點映射（舊→新）
- [ ] Request/Response 格式對齊
- [ ] 認證/授權機制遷移
- [ ] 錯誤碼統一

#### 步驟 4.2：功能替換映射

| 舊技術 | 新技術等價方案 |
|--------|-------------|
| Python decorator | Spring AOP / @Annotation |
| Flask middleware | Spring Filter / Interceptor |
| Celery task | @Scheduled / Spring Batch |
| SQLAlchemy ORM | JPA / Hibernate |

> 🔴 **人機協作點：API 契約確認**

---

### 階段 5：前端遷移設計 (30-40 分鐘規劃)

#### 步驟 5.1：元件映射

| 舊元件 | 新元件 | 備註 |
|--------|--------|------|
| Vue SFC (.vue) | React Component (.tsx) | 模板→JSX |
| Pinia Store | Zustand / Redux | 狀態管理 |
| Vue Router | Next.js App Router | 路由系統 |
| Vuetify / Element Plus | MUI / Ant Design | UI 庫 |
| Composables | Custom Hooks | 邏輯復用 |

#### 步驟 5.2：頁面遷移順序

建議按業務優先級排序：
1. 核心頁面（進貨/銷貨/庫存查詢）
2. 報表頁面
3. 系統管理頁面
4. 其他次要頁面

> 🔴 **人機協作點：前端遷移計畫確認**

---

### 階段 6：新平台開發設計 (僅涉及新平台時, 20-30 分鐘)

**載入 Agents**: SD-Mobile-Architect, Integration-Specialist

- [ ] 行動端架構設計（原生 vs 跨平台）
- [ ] 共用 API 設計
- [ ] 離線支援策略
- [ ] 掃碼/硬體功能設計
- [ ] 推播通知設計

> 🔴 **人機協作點：行動端方案確認**

---

### 階段 7：驗證與測試規劃 (30-40 分鐘)

**載入 Agents**: QA (Lead), Code-Analyzer

#### 多維度驗證

**資料庫遷移驗證**：
- [ ] Schema 對齊（表/欄位/約束/索引）
- [ ] 資料完整性（逐表行數、主鍵、金額加總）
- [ ] SP 邏輯等價（同輸入→同輸出）

**跨系統一致性驗證**：
- [ ] API 響應比對（同請求→同回傳）
- [ ] 業務計算比對（進貨/銷貨/庫存結餘）
- [ ] 報表數據比對

**行動端驗證**（涉及新平台時）：
- [ ] 多裝置/多版本測試
- [ ] 掃碼功能各格式測試
- [ ] 離線/弱網路測試

**部署驗證**：
- [ ] 藍綠/金絲雀發布驗證
- [ ] 回滾機制測試
- [ ] 監控告警測試

> 🔴 **人機協作點：測試計畫確認**

---

### 階段 8：部署與切換 (20-30 分鐘規劃)

**載入 Agents**: DevOps, SD

- [ ] CI/CD Pipeline 建立（新技術棧）
- [ ] 並行運行啟動
- [ ] 漸進式流量切換計畫
- [ ] 舊系統退役計畫
- [ ] 監控與告警設定

> 🔴 **人機協作點：部署方案確認**

---

### 階段 9：知識沉澱 (20 分鐘)

- [ ] 遷移映射手冊（前端/後端/DB 對照表）
- [ ] 架構決策記錄 (ADR)
- [ ] 經驗教訓文檔
- [ ] 新技術棧開發規範

---

## 🎯 成功標準

- [ ] 所有業務功能 100% 對等
- [ ] 資料遷移 100% 完整準確
- [ ] 測試覆蓋率 ≥80%
- [ ] 效能無退化（或有改善）
- [ ] 並行運行期間零資料不一致
- [ ] 成功切換且舊系統安全退役

---

## 📊 時間分配參考

| 階段 | 規劃時間 | 執行時間（中規模） |
|------|---------|----------------|
| 現況分析與需求提取 | 1-2 小時 | - |
| 遷移架構設計 | 1-1.5 小時 | - |
| 資料庫遷移 | 0.5-1 小時 | 2-4 週 |
| 後端遷移 | 30-40 分鐘 | 4-6 週 |
| 前端遷移 | 30-40 分鐘 | 6-8 週 |
| 新平台開發 | 20-30 分鐘 | 4-6 週 |
| 驗證與測試 | 30-40 分鐘 | 2-3 週 |
| 部署與切換 | 20-30 分鐘 | 1-2 週 |
| 知識沉澱 | 20 分鐘 | 2-3 天 |
| **規劃總計** | **4-8 小時** | |
| **執行總計** | | **8-20 週** |

---

## 📖 深度技術參考

> **技術棧遷移深度指南**：完整的資料型別映射、SQL 語法轉換、SP 遷移細節、
> 前端框架映射等技術細節，請參閱 [Refactoring SOP_DeepDive Part 11](../refactoring/SOP_DeepDive.md)。
> Part 11 同時適用於 Migration SOP（全棧遷移）和 Refactoring SOP（部分替換）。

---

## 📚 參考資源

### 相關文檔
- [Migration QuickRef](./SOP_QuickRef.md)
- [Migration 快速啟動指令集](../../prompts/scenario-prompts/migration-prompts.md)
- [Refactoring DeepDive Part 11 - 技術棧遷移深度指南](../refactoring/SOP_DeepDive.md)
- [AISDLC_INIT.md](../../AISDLC_INIT.md)

### 相關 Skills
- `/database-migration` - 資料庫遷移
- `/mobile-development` - 行動端開發
- `/integration-database` - DB 整合方案
- `/integration-api-client` - API 契約設計
- `/performance-optimization` - 效能基準對比

### 文檔範本
- [Migration_Mapping_Report_Template.md](../../docs_template/scenario_specific/migration/Migration_Mapping_Report_Template.md)
- [DB_Migration_Plan_Template.md](../../docs_template/scenario_specific/migration/DB_Migration_Plan_Template.md)
- [Migration_Verification_Report_Template.md](../../docs_template/scenario_specific/migration/Migration_Verification_Report_Template.md)

---

**文檔版本**: v0.09
**最後更新**: 2026-02-16
**基於**: AISDLC v0.09 Migration 情境模擬測試改善
