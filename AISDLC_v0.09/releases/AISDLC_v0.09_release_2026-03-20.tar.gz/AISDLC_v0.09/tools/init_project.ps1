# AISDLC 專案初始化腳本 (PowerShell 版本)
# 版本: v3.1
# 最後更新: 2026-02-07
# 適用於: Windows 11/10, PowerShell 5.1+
# 用途: 從 GitHub 下載並初始化 AISDLC 框架到專案目錄
# 支援: 公開倉庫 (HTTPS) / 私有倉庫 (SSH)

param(
    [Alias("v")]
    [string]$Version = "0.08",

    [Alias("d")]
    [string]$Dir = ".",

    [Alias("s")]
    [switch]$SSH,

    [Alias("h")]
    [switch]$Help
)

# ===== 配置 =====
$GITHUB_REPO = "wuweihungmobile/AISDLC"
$GITHUB_URL_HTTPS = "https://github.com/$GITHUB_REPO.git"
$GITHUB_URL_SSH = "git@github.com:$GITHUB_REPO.git"
$DEFAULT_VERSION = "0.08"

# 設定錯誤處理
$ErrorActionPreference = "Stop"

# ===== 輔助函數 =====

function Show-Banner {
    Write-Host "╔════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║       AISDLC 專案初始化工具 v3.1                      ║" -ForegroundColor Cyan
    Write-Host "║       AI-assisted Software Development Lifecycle       ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
}

function Show-Usage {
    Write-Host "使用方式:" -ForegroundColor Blue
    Write-Host "  .\init_project.ps1 [選項]"
    Write-Host ""
    Write-Host "選項:" -ForegroundColor Blue
    Write-Host "  -Version, -v VERSION   指定 AISDLC 版本 (預設: $DEFAULT_VERSION)"
    Write-Host "  -Dir, -d DIRECTORY     指定安裝目錄 (預設: 當前目錄)"
    Write-Host "  -SSH, -s               使用 SSH 連線 (私有倉庫需要)"
    Write-Host "  -Help, -h              顯示此說明"
    Write-Host ""
    Write-Host "🌐 遠端安裝 (從 GitHub 直接執行):" -ForegroundColor Blue
    Write-Host ""
    Write-Host "  # 公開倉庫 - 一行安裝" -ForegroundColor Green
    Write-Host "  irm https://raw.githubusercontent.com/$GITHUB_REPO/main/AISDLC_v$DEFAULT_VERSION/tools/init_project.ps1 | iex"
    Write-Host ""
    Write-Host "  # 公開倉庫 - 指定版本和目錄 (需先下載)" -ForegroundColor Green
    Write-Host "  irm https://raw.githubusercontent.com/$GITHUB_REPO/main/AISDLC_v$DEFAULT_VERSION/tools/init_project.ps1 -OutFile init.ps1; .\init.ps1 -v 0.08 -d .\my-project"
    Write-Host ""
    Write-Host "  # 私有倉庫 - 需先下載後執行" -ForegroundColor Green
    Write-Host "  irm https://raw.githubusercontent.com/$GITHUB_REPO/main/AISDLC_v$DEFAULT_VERSION/tools/init_project.ps1 -OutFile init.ps1; .\init.ps1 -SSH"
    Write-Host ""
    Write-Host "📁 本地安裝:" -ForegroundColor Blue
    Write-Host ""
    Write-Host "  # 公開倉庫 - 安裝預設版本到當前目錄"
    Write-Host "  .\init_project.ps1"
    Write-Host ""
    Write-Host "  # 私有倉庫 - 使用 SSH 連線"
    Write-Host "  .\init_project.ps1 -SSH"
    Write-Host ""
    Write-Host "  # 安裝指定版本到指定目錄"
    Write-Host "  .\init_project.ps1 -Version 0.08 -Dir C:\Projects\MyApp -SSH"
    Write-Host ""
    Write-Host "💡 提示:" -ForegroundColor Yellow
    Write-Host "  • 公開倉庫: 直接使用 HTTPS (預設)"
    Write-Host "  • 私有倉庫: 使用 -SSH 並確保已設定 SSH Key"
    Write-Host ""
}

function Test-Dependencies {
    Write-Host "⏳ 檢查必要工具..." -ForegroundColor Yellow

    $missingDeps = @()

    # Check for Git
    try {
        $null = Get-Command git -ErrorAction Stop
    } catch {
        $missingDeps += "git"
    }

    if ($missingDeps.Count -ne 0) {
        Write-Host "❌ 缺少必要工具: $($missingDeps -join ', ')" -ForegroundColor Red
        Write-Host "   請先安裝缺少的工具後再執行此腳本" -ForegroundColor Yellow
        Write-Host "   Git 下載: https://git-scm.com/download/win" -ForegroundColor Yellow
        exit 1
    }

    Write-Host "✅ 所有必要工具已安裝" -ForegroundColor Green
    Write-Host ""
}

function Get-AISDLC {
    param(
        [string]$TargetVersion,
        [string]$TargetDir,
        [bool]$UseSSH
    )

    $tempDir = Join-Path $env:TEMP "aisdlc_temp_$(Get-Random)"
    $aisdlcDir = "AISDLC_v$TargetVersion"

    # 選擇 URL
    if ($UseSSH) {
        $gitUrl = $GITHUB_URL_SSH
        Write-Host "⏳ 從 GitHub 下載 AISDLC v$TargetVersion (SSH)..." -ForegroundColor Yellow
    } else {
        $gitUrl = $GITHUB_URL_HTTPS
        Write-Host "⏳ 從 GitHub 下載 AISDLC v$TargetVersion (HTTPS)..." -ForegroundColor Yellow
    }
    Write-Host "   倉庫: $gitUrl" -ForegroundColor Blue

    try {
        # Clone with depth 1 for speed
        $gitOutput = git clone --depth 1 --quiet $gitUrl "$tempDir\repo" 2>&1

        if ($LASTEXITCODE -ne 0) {
            throw "Git clone failed"
        }
    } catch {
        Write-Host "❌ 無法連線到 GitHub 倉庫" -ForegroundColor Red
        if (-not $UseSSH) {
            Write-Host "   若為私有倉庫，請使用 -SSH 選項" -ForegroundColor Yellow
        } else {
            Write-Host "   請確認 SSH Key 已正確設定" -ForegroundColor Yellow
        }
        if (Test-Path $tempDir) { Remove-Item -Recurse -Force $tempDir }
        exit 1
    }

    # Check if version directory exists
    $versionPath = Join-Path "$tempDir\repo" $aisdlcDir
    if (-not (Test-Path $versionPath)) {
        Write-Host "❌ 找不到版本 v$TargetVersion" -ForegroundColor Red
        Write-Host "   可用版本:" -ForegroundColor Yellow
        Get-ChildItem "$tempDir\repo" -Directory -Filter "AISDLC_v*" | ForEach-Object {
            $vName = $_.Name -replace "AISDLC_v", ""
            Write-Host "   - v$vName"
        }
        Remove-Item -Recurse -Force $tempDir
        exit 1
    }

    Write-Host "✅ 下載完成" -ForegroundColor Green

    # Copy to target directory
    Write-Host "⏳ 複製 AISDLC v$TargetVersion 到專案目錄..." -ForegroundColor Yellow

    # Create target directory if not exists
    if (-not (Test-Path $TargetDir)) {
        New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
    }

    # Copy AISDLC version directory
    $destPath = Join-Path $TargetDir $aisdlcDir
    Copy-Item -Path $versionPath -Destination $destPath -Recurse -Force

    # Copy CLAUDE.md if exists
    $claudeMdPath = Join-Path "$tempDir\repo" "CLAUDE.md"
    if (Test-Path $claudeMdPath) {
        Copy-Item -Path $claudeMdPath -Destination $TargetDir -Force
        Write-Host "   ✅ 複製 CLAUDE.md" -ForegroundColor Green
    }

    # Copy .claude/skills/ to project root (Claude Code Skills discovery)
    $skillsSrcPath = Join-Path $destPath ".claude\skills"
    if (Test-Path $skillsSrcPath) {
        $skillsDestPath = Join-Path $TargetDir ".claude\skills"
        New-Item -ItemType Directory -Path $skillsDestPath -Force | Out-Null
        Copy-Item -Path "$skillsSrcPath\*" -Destination $skillsDestPath -Recurse -Force
        Write-Host "   ✅ 複製 .claude/skills/ (31 個 Claude Code Skills)" -ForegroundColor Green
    }

    Write-Host "✅ 複製完成" -ForegroundColor Green

    # Cleanup
    Remove-Item -Recurse -Force $tempDir

    Write-Host ""
}

function New-DocsDirectories {
    param(
        [string]$BaseDir,
        [string]$AisdlcDir
    )

    Write-Host "⏳ 建立 docs/ 標準子目錄..." -ForegroundColor Yellow

    # 定義標準子目錄（開發專注版）
    $docsDirs = @(
        "docs\01_requirements",
        "docs\02_architecture",
        "docs\03_testing",
        "docs\04_planning",
        "docs\05_development",
        "docs\06_quality",
        "docs\07_design",
        "docs\08_deployment"
    )

    $createdCount = 0
    $existingCount = 0
    $targetPath = Join-Path $BaseDir $AisdlcDir

    foreach ($dir in $docsDirs) {
        $fullPath = Join-Path $targetPath $dir
        if (-not (Test-Path $fullPath)) {
            New-Item -ItemType Directory -Path $fullPath -Force | Out-Null
            Write-Host "   ✅ 建立 $dir\" -ForegroundColor Green
            $createdCount++
        } else {
            Write-Host "   ℹ️  $dir\ 已存在" -ForegroundColor Blue
            $existingCount++
        }
    }

    Write-Host ""
    Write-Host "📊 統計結果:" -ForegroundColor Green
    Write-Host "   - 已存在: $existingCount 個目錄"
    Write-Host "   - 新建立: $createdCount 個目錄"
    Write-Host ""
}

function Show-CompletionMessage {
    param(
        [string]$TargetDir,
        [string]$TargetVersion
    )

    $aisdlcDir = "AISDLC_v$TargetVersion"
    $claudeMdExists = Test-Path (Join-Path $TargetDir "CLAUDE.md")

    Write-Host "╔════════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "║              ✅ 初始化完成！                           ║" -ForegroundColor Green
    Write-Host "╚════════════════════════════════════════════════════════╝" -ForegroundColor Green
    Write-Host ""
    Write-Host "📋 已完成的工作:" -ForegroundColor Blue
    Write-Host "   ✅ 從 GitHub 下載 AISDLC v$TargetVersion"
    Write-Host "   ✅ 複製框架到 $TargetDir\$aisdlcDir\"
    Write-Host "   ✅ 建立 docs\ 標準子目錄"
    if ($claudeMdExists) {
        Write-Host "   ✅ 複製 CLAUDE.md 設定檔"
    }
    $skillsExists = Test-Path (Join-Path $TargetDir ".claude\skills")
    if ($skillsExists) {
        Write-Host "   ✅ 部署 .claude/skills/ (Claude Code Skills)"
    }
    Write-Host ""
    Write-Host "📝 下一步:" -ForegroundColor Yellow
    Write-Host "   1. cd $TargetDir\$aisdlcDir"
    Write-Host "   2. 閱讀 AISDLC_INIT.md 了解框架使用"
    Write-Host "   3. PRD 寫入 docs\01_requirements\"
    Write-Host "   4. SRD 寫入 docs\02_architecture\"
    Write-Host "   5. 參考: guides\user\onboarding\QUICK_START_GUIDE.md"
    Write-Host ""
    Write-Host "🔗 專案結構:" -ForegroundColor Cyan
    Write-Host "   $TargetDir\"
    Write-Host "   ├── $aisdlcDir\          # AISDLC 框架"
    Write-Host "   │   ├── agent\              # AI Agent 定義"
    Write-Host "   │   ├── workflow\           # 工作流程"
    Write-Host "   │   ├── docs\               # 📄 您的專案文件放這裡"
    Write-Host "   │   ├── docs_template\      # 文件模板"
    Write-Host "   │   ├── guides\             # 參考指南"
    Write-Host "   │   └── AISDLC_INIT.md      # 框架入口"
    Write-Host "   ├── .claude/skills/         # Claude Code Skills (31個)"
    Write-Host "   └── CLAUDE.md               # Claude Code 設定"
    Write-Host ""
}

# ===== 主程式 =====

function Main {
    # Show help if requested
    if ($Help) {
        Show-Banner
        Show-Usage
        exit 0
    }

    # Resolve target directory to absolute path
    $targetDir = $Dir
    if ($targetDir -eq ".") {
        $targetDir = Get-Location
    } else {
        # Create if not exists for path resolution
        if (-not (Test-Path $targetDir)) {
            New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
        }
        $targetDir = Resolve-Path $targetDir
    }

    Show-Banner

    Write-Host "📦 安裝配置:" -ForegroundColor Blue
    Write-Host "   版本: v$Version"
    Write-Host "   目錄: $targetDir"
    Write-Host ""

    Test-Dependencies
    Get-AISDLC -TargetVersion $Version -TargetDir $targetDir -UseSSH $SSH.IsPresent
    New-DocsDirectories -BaseDir $targetDir -AisdlcDir "AISDLC_v$Version"
    Show-CompletionMessage -TargetDir $targetDir -TargetVersion $Version
}

# 執行主程式
Main
