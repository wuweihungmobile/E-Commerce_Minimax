# DevOps Setup Flow
# DevOps 建置與 CI/CD 實作流程

## Workflow 名稱
**devops-setup-flow** - DevOps 完整建置流程

## 描述
建立完整的 DevOps 體系，包含環境規劃、CI/CD Pipeline、容器化、自動化測試、監控、災難恢復和成本優化。
支援多技術棧：Java/Spring Boot、React/Next.js、Android、macOS 桌面應用。

## 適用場景
- **使用時機**：專案啟動、DevOps 轉型、CI/CD 建置
- **適用專案**：所有需要自動化部署的專案（Web、API、行動端、桌面端）
- **執行頻率**：專案初期一次性建置，後續持續優化

## 觸發條件
- 專案需要自動化部署
- 代碼庫已建立
- 基礎設施可存取

---

# 角色與責任

## 主要負責人
**Agent 角色**：DevOps-Engineer (Lead) + SD-Architect (Infrastructure)
**責任**：DevOps 架構設計、CI/CD 建置

## 參與者
- **QA-Automation**：測試自動化整合 CI/CD
- **Dev-Developer**：Pipeline 腳本開發與部署腳本實作
- **Security-Engineer**：DevSecOps 安全掃描整合（SAST/DAST/依賴掃描）

## 可選參與者
- **SD-Mobile-Architect**：行動端 CI/CD（Android/macOS）建置時加入
- **QA-Mobile-Tester**：行動端自動化測試整合時加入
- **Performance-Engineer**：效能測試整合 CI/CD 時加入

---

# 執行步驟

## 步驟 1：環境規劃與架構設計 (40-60 分鐘)
**執行者**：DevOps-Engineer + SD

**作業內容**：
1. 環境分層設計（Local/Dev/Staging/Prod）
2. 基礎設施選型
3. 網路架構設計
4. IaC（Infrastructure as Code）設計

**確認點** 🔴：環境規劃確認
- 審查環境架構圖
- 確認基礎設施選型
- 確認成本預估

**產出**：環境規劃文件、基礎設施架構圖、IaC 配置

## 步驟 2：CI Pipeline 設計 (1-1.5 小時)
**執行者**：DevOps-Engineer + QA-Automation

**作業內容**：
1. 設計 CI Pipeline 流程
2. 配置 Quality Gates
3. Docker 容器化
4. 測試自動化整合

**確認點** 🔴：CI Pipeline 確認
- 審查 CI Pipeline 配置
- 確認 Quality Gates
- 確認容器化方案

**產出**：CI Pipeline 配置、Dockerfile、Docker Compose

## 步驟 3：CD Pipeline 設計 (1-1.5 小時)
**執行者**：DevOps-Engineer

**作業內容**：
1. 選擇部署策略（Rolling/Blue-Green/Canary）
2. 設計 CD Pipeline
3. Kubernetes 配置（如適用）
4. 自動擴展配置

**確認點** 🔴：CD Pipeline 確認
- 審查部署策略
- 確認 CD Pipeline
- 確認回滾方案

**產出**：CD Pipeline 配置、Kubernetes Manifests、部署 Runbook

## 步驟 4：監控與告警 (40-60 分鐘)
**執行者**：DevOps-Engineer

**作業內容**：
1. 建立監控體系（四大黃金指標）
2. 配置 Prometheus + Grafana
3. 設定告警規則
4. 配置應用程式指標

**確認點** 🔴：監控確認

**產出**：監控方案、Grafana 儀表板、告警規則

## 步驟 5：災難恢復與備份 (30-40 分鐘)
**執行者**：DevOps-Engineer

**作業內容**：
1. 設計備份策略（資料庫自動備份、異地備份）
2. 定義 RTO/RPO
3. 制定災難恢復計畫
4. 準備回復腳本

**產出**：備份策略、災難恢復計畫、RTO/RPO 定義

## 步驟 6：安全整合 DevSecOps (30-40 分鐘)
**執行者**：DevOps-Engineer + Security-Engineer

**作業內容**：
1. CI 整合安全掃描（SAST、依賴漏洞掃描）
2. Container Image 安全掃描（Trivy/Snyk）
3. Secret 管理方案（Vault/SOPS/GitHub Secrets）
4. HTTPS/TLS 憑證管理自動化

**確認點** 🔴：安全整合確認
- 審查安全掃描配置
- 確認 Secret 管理方案
- 確認合規需求覆蓋

**產出**：DevSecOps Pipeline 配置、Secret 管理方案

## 步驟 7：成本優化與文檔 (30-40 分鐘)
**執行者**：DevOps-Engineer

**作業內容**：
1. 資源使用量估算與成本優化
2. 成本告警設定
3. Runbook 與操作文檔撰寫
4. 團隊培訓材料準備

**產出**：成本優化方案、Runbook、操作手冊

---

# 輸出與交付

## 主要交付物
- 環境規劃文件
- CI/CD Pipeline 配置（支援多技術棧）
- 容器化方案（Dockerfile + Docker Compose + K8s Manifests）
- 監控方案（Prometheus + Grafana + 告警規則）
- 災難恢復計畫
- DevSecOps 安全配置
- 成本優化方案與 Runbook

## 交付標準
- CI/CD 自動化（建置 < 10 分鐘）
- 零停機部署
- 監控完整（四大黃金指標）
- 回滾可用（< 5 分鐘）
- 安全掃描整合

**版本**：v0.09
